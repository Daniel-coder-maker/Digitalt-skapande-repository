﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;

public class Settings : MonoBehaviour
{
    public AudioMixer audiomixer;
    public AudioMixer musicmixer;
    public AudioMixer soundmixer;
    public AudioMixer voicemixer;

   public void SetVolume(float volume)
    {
        audiomixer.SetFloat("Volume", volume);
    }

    public void SetMusic(float volume)
    {
        musicmixer.SetFloat("VolumeM", volume);
    }

    public void SetSound(float volume)
    {
        soundmixer.SetFloat("VolumeS", volume);
    }

    public void SetVoice(float volume)
    {
        voicemixer.SetFloat("VolumeV", volume);
    }
}
